package Exceptions;
public class FarmerListLimitExceededException extends Exception {
    public FarmerListLimitExceededException() {
        super();

    }    
}
