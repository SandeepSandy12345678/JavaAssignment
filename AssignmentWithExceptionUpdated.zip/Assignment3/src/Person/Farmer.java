package Person;

public class Farmer implements Person {
    String name;
    Long mobileno;//sometimes of the range of long it cannot take all 10 digits sometimes it is better to use String for phone

    public Farmer(String name, Long mobileno) {
        this.name = name;
        this.mobileno =mobileno;
    }

    @Override
    public void addWholesaler() {

    }

    @Override
    public void addFarmer(Farmer f) {

    }

    public String getName() {
        return this.name;
    }

    public long getContact() {
        return this.mobileno;
    }

}

