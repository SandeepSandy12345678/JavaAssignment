import Person.Farmer;
import Person.WholeSaler;
public class Main {
    
    public static void main(String[] args)  {
        WholeSaler wholeSaler1 = new WholeSaler("Akash Thallam",(long) 122223334);
        System.out.println(wholeSaler1);
        Farmer farmer1 = new Farmer("karthick suburaj", (long) 810585810);
        Farmer farmer2 = new Farmer("Lokesh kangaraj", (long) 1234522221);
        Farmer farmer3 = new Farmer("Rakshith", (long) 1567854601);
        Farmer farmer4 = new Farmer("Rajath", (long) 675747890);
        Farmer farmer5 = new Farmer("Lokesh", (long) 987348400);
        Farmer farmer6 = new Farmer("Karthick", (long) 987890886);
        Farmer farmer7 = new Farmer("Sagar",(long)971234567);
        Farmer farmer8 = new Farmer("raj",(long)998040302);
        try {
            wholeSaler1.addFarmer(farmer1);
            wholeSaler1.addFarmer(farmer2);
            wholeSaler1.addFarmer(farmer3);
            wholeSaler1.addFarmer(farmer4);
            wholeSaler1.addFarmer(farmer5);
            wholeSaler1.addFarmer(farmer6);
            wholeSaler1.addFarmer(farmer7);
            wholeSaler1.addFarmer(farmer8);

        } catch ( Exception e) {
            System.out.println("you cannot add more than 5 Farmers to the  List");
        }
        System.out.println("Farmers_List");
        System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        for (Farmer g : wholeSaler1.farmer) {
            System.out.printf("\n Farmer name "+g.getName() +" and Phone number "+g.getContact());
        }

    }

}
