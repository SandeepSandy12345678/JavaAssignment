import Person.Farmer;
import Person.WholeSaler;
public class Main {
    
    public static void main(String[] args)  {

        WholeSaler wholeSaler1 = new WholeSaler("Akash Thallam",(long) 1222233344);

        Farmer farmer1 = new Farmer("karthick suburaj", (long) 810585841);
        Farmer farmer2 = new Farmer("Lokesh kangaraj", (long) 123452222);
        Farmer farmer3 = new Farmer("Rakshith", (long) 15678546);
        Farmer farmer4 = new Farmer("Rajath", (long) 67574789);
        Farmer farmer5 = new Farmer("Lokesh", (long) 987348476);
        Farmer farmer6 = new Farmer("Karthick", (long) 987890886);
        Farmer farmer7 = new Farmer("Sagar",(long)973930492);
        Farmer farmer8 = new Farmer("raj",(long)998040302);
        try {
            wholeSaler1.addFarmer(farmer1);
            wholeSaler1.addFarmer(farmer2);
            wholeSaler1.addFarmer(farmer3);
            wholeSaler1.addFarmer(farmer4);
            wholeSaler1.addFarmer(farmer5);
            wholeSaler1.addFarmer(farmer6);
            wholeSaler1.addFarmer(farmer7);
            wholeSaler1.addFarmer(farmer8);

        } catch (Exception e) {
            System.out.println("You cannot add more than 6 farmers to the farmers list");
        }

        System.out.println("Farmers_List");
        System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        for (Farmer g : wholeSaler1.farmer) {
            System.out.printf("\n Farmer name"+g.getName() +" and Phone number"+g.getContact());
        }

    }

}
